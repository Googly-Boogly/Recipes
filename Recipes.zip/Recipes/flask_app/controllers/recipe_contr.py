from flask import render_template,redirect,request,session,flash
from flask_app.models.users import User
from flask_app.models.recipes import Recipe
from flask_app.templates import app
from flask_bcrypt import Bcrypt
import re
bcrypt = Bcrypt(app)


@app.route("/dashboard")
def show_recipes():
    if not session['user_id']:
        return redirect('/')
    recipes = Recipe.get_all()
    return render_template("dashboard.html", user_name=session['name'], recipes=recipes, user_id=session['user_id'])

@app.route("/recipes/new")
def create_recipe():
    if not session['user_id']:
        return redirect('/')
    return render_template("new.html", user_name=session['name'])

@app.route('/recipes/edit/<int:id_1>')
def edit_recipe(id_1):
    session['recipe_id'] = id_1
    oop = {'id': id_1}
    print(oop)
    print('FDGDDFDFKJGJDFBGDFGKLDJFGKLDFG')
    data = Recipe.get_one(oop)
    data[0]['user_id'] = session['user_id']
    return render_template('edit.html', data=data[0], user_name=session['name'], sesh_id=session['user_id'], oop=oop)

@app.route('/recipes/<int:id_1>')
def recipe_view(id_1):
    oop = {'id': id_1}
    data = (Recipe.get_one(oop))[0]
    print(data)
    return render_template('show_recipe.html', data=data)
@app.route("/recipes/update", methods=['POST'])
def update_recipe():
    if not Recipe.validate_recipe(request.form):
        return redirect('/dashboard')
    print('HIIIIIIIGDFGDFGDFGDFG')
    und_30 = True
    if request.form['under_30'] == 'yes':
        und_30 = True
    else:
        und_30 = False
    data = {
        'id': session['recipe_id'],
        'name': request.form['name'],
        'description': request.form['description'],
        'instructions': request.form['instructions'],
        'user_id': session['user_id'],
        'under_30': und_30,
        'created_at': request.form['created_at']
    }
    print(Recipe.update_one(data))
    return redirect('/dashboard')

@app.route('/recipes/delete/<int:id_1>', methods=['POST'])
def delete_recipe(id_1):
    data = {
        'id': id_1
    }
    Recipe.delete_one(data)
    return redirect('/dashboard')
@app.route("/recipes/new/create", methods=['POST'])
def create_new_recipe():
    if not Recipe.validate_recipe(request.form):
        return redirect('/recipes/new/create')
    und_30 = True
    if request.form['under_30'] == 'yes':
        und_30 = True
    else:
        und_30 = False
    data = {
        'name': request.form['name'],
        'description': request.form['description'],
        'instructions': request.form['instructions'],
        'user_id': session['user_id'],
        'under_30': und_30,
        'created_at': request.form['created_at']
    }
    Recipe.save(data)
    return redirect('/dashboard')
