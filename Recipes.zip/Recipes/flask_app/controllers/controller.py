from flask import render_template,redirect,request,session,flash
from flask_app.models.users import User
from flask_app.templates import app
from flask_bcrypt import Bcrypt
import re
bcrypt = Bcrypt(app)

@app.route("/")
def register():

    return render_template("register.html")

@app.route('/create_user', methods=['POST'])
def create_user():
    if not User.validate_creds(request.form):
        return redirect('/')
    pw_hash = bcrypt.generate_password_hash(request.form['password'])
    data = {
        'email': request.form['email'],
        'first_name': request.form['first_name'],
        'last_name': request.form['last_name'],
        'password': pw_hash,
        
    }
    
    
    User.save(data)
    return redirect("/")

@app.route('/loggout', methods=['POST'])
def logout():
    session['user_id'] = ''
    session['name'] = ''
    return redirect("/")

@app.route('/login', methods=['POST'])
def login2():
    # see if the username provided exists in the database
    data = { "email" : request.form["email"] }
    user_in_db = User.get_by_email(data)
    # user is not registered in the db
    if not user_in_db:
        flash("Invalid Email/Password")
        return redirect("/")
    if not bcrypt.check_password_hash(user_in_db.password, request.form['password']):
        # if we get False after checking the password
        flash("Invalid Email/Password")
        return redirect('/')
    # if the passwords matched, we set the user_id into session
    session['user_id'] = user_in_db.id
    # never render on a post!!!
    session['name'] = user_in_db.first_name
    return redirect("/dashboard")
