from flask_app.config.mysqlconnection import connectToMySQL
from flask import Flask, render_template, request, redirect, flash
import re
from flask_bcrypt import Bcrypt  

class Recipe:
    db = 'recipes'
    def __init__( self , data):
        self.id = data['id']
        self.name = data['name']
        self.under_30 = data['under_30']
        self.instructions = data['instructions']
        self.user_id = data['user_id']
        self.description = data['description']
        self.updated_at = data['updated_at']
        self.created_at = data['created_at']
    @classmethod
    def save(cls, data ):
        query = "INSERT INTO recipes ( name, under_30, instructions, description, user_id, created_at) VALUES ( %(name)s, %(under_30)s, %(instructions)s, %(description)s, %(user_id)s, %(created_at)s);"
        return connectToMySQL(cls.db).query_db( query, data )
    @staticmethod
    def get_one(id):
        query = "SELECT * FROM recipes WHERE id = %(id)s;"
        return connectToMySQL(Recipe.db).query_db( query, id)
    @staticmethod
    def delete_one(data):
        query = 'DELETE FROM recipes WHERE id = %(id)s'
        return connectToMySQL(Recipe.db).query_db( query, data)
    @staticmethod
    def update_one(data):
        query = "UPDATE recipes SET name = %(name)s, under_30 = %(under_30)s, instructions = %(instructions)s, created_at = %(created_at)s, description = %(description)s WHERE id = %(id)s;"
        print(query)
        return connectToMySQL(Recipe.db).query_db( query, data)
    @staticmethod
    def get_all():
        query = "SELECT * FROM recipes;"
        return connectToMySQL(Recipe.db).query_db( query)
    @staticmethod
    def validate_recipe(data):
        validate = True
        if len(data['name']) < 2:
            validate = False
            flash('Name needs to be greater than 2 characters', 'Name')
        if data['name'] == '':
            validate = False
            flash('Name needs to be submitted', 'Name')
        if not data['name'].isalpha():
            validate = False
            flash('Name needs to be only alphabet characters', 'Name')
        if len(data['description']) < 2:
            validate = False
            flash('description needs to be greater than 2 characters', 'description')
        if data['description'] == '':
            validate = False
            flash('description needs to be submitted', 'description')
        if len(data['instructions']) < 2:
            validate = False
            flash('instructions needs to be greater than 2 characters', 'instructions')
        if data['instructions'] == '':
            validate = False
            flash('instructions needs to be submitted', 'instructions')
        
        return validate
